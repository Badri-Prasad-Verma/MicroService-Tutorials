package com.HotelPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
