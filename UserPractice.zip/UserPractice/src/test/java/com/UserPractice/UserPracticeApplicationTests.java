package com.UserPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
