package com.RatingPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatingPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatingPracticeApplication.class, args);
	}

}
